export const getQueryParams = async () => {
    return await ZOHO.CREATOR.UTIL.getQueryParams();
}

export const getInitParams = async () => {
    return await ZOHO.CREATOR.UTIL.getInitParams();
}